package com.example.thymelaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymelafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymelafApplication.class, args);
	}
}
